    /**
 * 
 * 乐购商城JS
 * 2020-10-22 by zcw
 */
//当页面加载完毕
    
    /* 返回顶部 */
    $(function (){
        //把函数挂早window上显示
window. goToTop = function(){
    //结构
    var goToTopHtml = $(`<div class="backToTop">
    <img src="../img/gototop_05.jpg" alt="">
                        </div>` );
}
})
